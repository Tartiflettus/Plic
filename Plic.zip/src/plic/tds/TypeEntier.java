package plic.tds;

public class TypeEntier extends Type {

	public TypeEntier() {
		super("entier");
	}
	
}
