package plic.arbre.instruction;

import plic.arbre.ArbreAbstrait;

public abstract class Instruction extends ArbreAbstrait {

	protected Instruction(int no) {
		super(no);
	}

}
